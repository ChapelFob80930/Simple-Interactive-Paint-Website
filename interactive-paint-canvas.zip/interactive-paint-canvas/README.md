# Interactive Paint Canvas

A Pen created on CodePen.io. Original URL: [https://codepen.io/ChapelFob80930/pen/bGPGMPe](https://codepen.io/ChapelFob80930/pen/bGPGMPe).

